<?php

namespace NFSePrefeitura\NFSe\Exceptions;

class NfseProcessingException extends \Exception
{
    // Custom exception for NFSe processing errors
}